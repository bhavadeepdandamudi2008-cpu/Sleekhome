# SleekHome

An iPhone-style home screen launcher for Android, written in Kotlin with plain Views.

## Build and install
1. Install Android Studio (Koala or newer). Open this `SleekHome` folder.
2. Let Gradle sync (needs internet the first time).
3. Phone: Settings > About phone > tap Build number 7 times, then Developer options > turn on USB debugging.
4. Connect the phone by USB and press Run in Android Studio.
5. Press the Home button and choose SleekHome, then "Always".

## Go back to your normal launcher
Settings > Apps > Default apps > Home app > pick your original launcher. Or uninstall SleekHome.

## What it has
- Rounded-square app icons, 4 x 6 grid, labels with shadow
- Date and clock widget on page 1
- Dock with your default Phone, Messages, Browser and Camera apps
- Page dots, swipe left/right between pages
- Last page is an App Library with category cards (tap a card to see all its apps)
- Swipe down on a home page for search
- Long-press an app for App Info or Remove App
- Icon open animation
- Folders: long-press an app > Edit Home Screen, then drag one app onto the middle of another. Tap a folder to open it, rename it at the top, long-press an app inside to take it out
- Drag to rearrange: in edit mode, drag icons to a new spot; hold at the screen edge to move to the next page. Layout is saved
- Tap Done (top right), Back or Home to leave edit mode

## Easy things to change (MainActivity.kt)
- Grid size: `cols`, `rows`, `headerRows` in `rebuild()`
- Dock apps: `AppRepository.dockApps()`
- Colors and corner radius: `glassBackground()` in Views.kt, `ICON_PX` and corner factor in AppRepository.kt

## Limits
- Not Apple's artwork: icons are your phone's own apps masked to a rounded square. No Apple font, icons or wallpapers are included.
- No real background blur, the glass look is translucent white.
- Widgets are not built yet. Dock apps can't be rearranged.
- Page 1 holds 16 icons (the clock takes the top rows), other pages hold 24.
- Gesture navigation may behave differently with a third-party launcher on some phones. If swipe-up breaks, use 3-button navigation.
