package com.example.sleekhome

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.MediaStore

data class AppItem(
    val label: String,
    val component: ComponentName,
    val icon: Bitmap,
    val category: Int
) {
    val pkg: String get() = component.packageName
}

object AppRepository {

    private const val ICON_PX = 192

    val CATEGORY_ORDER = listOf(
        "Social", "Productivity", "Entertainment", "Photo & Video",
        "Games", "Maps & Travel", "Information & Reading", "Utilities"
    )

    fun load(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map { ri ->
                val ai = ri.activityInfo
                AppItem(
                    label = ri.loadLabel(pm).toString(),
                    component = ComponentName(ai.packageName, ai.name),
                    icon = renderIcon(ri.loadIcon(pm)),
                    category = ai.applicationInfo.category
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    /** Renders any app icon into a rounded-square tile (iOS-style corner radius). */
    private fun renderIcon(d: Drawable): Bitmap {
        val s = ICON_PX
        val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val r = s * 0.2237f
        val clip = Path().apply {
            addRoundRect(RectF(0f, 0f, s.toFloat(), s.toFloat()), r, r, Path.Direction.CW)
        }
        c.clipPath(clip)
        if (d is AdaptiveIconDrawable) {
            // Draw the raw layers so our own mask is used instead of the system's.
            val lo = (-s * 0.25f).toInt()
            val hi = s - lo
            d.background?.let { it.setBounds(lo, lo, hi, hi); it.draw(c) }
            d.foreground?.let { it.setBounds(lo, lo, hi, hi); it.draw(c) }
        } else {
            c.drawColor(0xFFF2F2F7.toInt())
            val pad = (s * 0.14f).toInt()
            d.setBounds(pad, pad, s - pad, s - pad)
            d.draw(c)
        }
        return out
    }

    /** Folder tile: translucent rounded square with up to 9 mini icons in a 3x3 grid. */
    fun renderFolderIcon(apps: List<AppItem>): Bitmap {
        val s = ICON_PX
        val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66FFFFFF }
        val r = s * 0.2237f
        c.drawRoundRect(RectF(0f, 0f, s.toFloat(), s.toFloat()), r, r, bg)
        val pad = s * 0.1f
        val gap = s * 0.04f
        val cell = (s - 2 * pad - 2 * gap) / 3f
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        apps.take(9).forEachIndexed { i, a ->
            val l = pad + (i % 3) * (cell + gap)
            val t = pad + (i / 3) * (cell + gap)
            c.drawBitmap(a.icon, null, RectF(l, t, l + cell, t + cell), p)
        }
        return out
    }

    fun categoryName(cat: Int): String = when (cat) {
        ApplicationInfo.CATEGORY_SOCIAL -> "Social"
        ApplicationInfo.CATEGORY_GAME -> "Games"
        ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> "Entertainment"
        ApplicationInfo.CATEGORY_IMAGE -> "Photo & Video"
        ApplicationInfo.CATEGORY_MAPS -> "Maps & Travel"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
        ApplicationInfo.CATEGORY_NEWS -> "Information & Reading"
        else -> "Utilities"
    }

    /** Picks the default phone, messages, browser and camera apps for the dock. */
    fun dockApps(ctx: Context, all: List<AppItem>): List<AppItem> {
        val pm = ctx.packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:")),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val result = mutableListOf<AppItem>()
        for (i in intents) {
            val pkg = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName ?: continue
            val match = all.firstOrNull { it.pkg == pkg && it !in result }
            if (match != null) result.add(match)
        }
        for (a in all) {
            if (result.size >= 4) break
            if (a !in result) result.add(a)
        }
        return result.take(4)
    }
}
