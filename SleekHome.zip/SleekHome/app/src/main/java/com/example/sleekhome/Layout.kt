package com.example.sleekhome

import android.content.Context
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** One thing on the home screen: a single app or a folder of apps. */
sealed class Entry {
    class App(val item: AppItem) : Entry()
    class Folder(var name: String, val apps: MutableList<AppItem>) : Entry()
}

/** Saves and restores the home screen order and folders. */
object LayoutStore {

    private const val PREFS = "layout"
    private const val KEY = "entries"

    private fun key(a: AppItem) = a.component.flattenToString()

    fun load(ctx: Context, apps: List<AppItem>, exclude: Set<String>): MutableList<Entry> {
        val byKey = apps.associateBy { key(it) }
        val used = HashSet<String>(exclude)
        val out = mutableListOf<Entry>()
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.getString("t") == "a") {
                        val k = o.getString("c")
                        val app = byKey[k]
                        if (app != null && used.add(k)) out.add(Entry.App(app))
                    } else {
                        val list = mutableListOf<AppItem>()
                        val ja = o.getJSONArray("a")
                        for (j in 0 until ja.length()) {
                            val k = ja.getString(j)
                            val app = byKey[k]
                            if (app != null && used.add(k)) list.add(app)
                        }
                        if (list.size >= 2) out.add(Entry.Folder(o.optString("n", "Folder"), list))
                        else if (list.size == 1) out.add(Entry.App(list[0]))
                    }
                }
            } catch (e: JSONException) {
                out.clear()
                used.clear()
                used.addAll(exclude)
            }
        }
        // Apps that are new (or not saved yet) go at the end.
        for (a in apps) {
            if (used.add(key(a))) out.add(Entry.App(a))
        }
        return out
    }

    fun save(ctx: Context, entries: List<Entry>) {
        val arr = JSONArray()
        for (e in entries) {
            val o = JSONObject()
            when (e) {
                is Entry.App -> {
                    o.put("t", "a")
                    o.put("c", key(e.item))
                }
                is Entry.Folder -> {
                    o.put("t", "f")
                    o.put("n", e.name)
                    val ja = JSONArray()
                    e.apps.forEach { ja.put(key(it)) }
                    o.put("a", ja)
                }
            }
            arr.put(o)
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    /** A folder with fewer than 2 apps dissolves back into plain apps. */
    fun normalize(entries: MutableList<Entry>) {
        var i = 0
        while (i < entries.size) {
            val e = entries[i]
            if (e is Entry.Folder && e.apps.size < 2) {
                entries.removeAt(i)
                if (e.apps.size == 1) entries.add(i, Entry.App(e.apps[0])) else i--
            }
            i++
        }
    }
}
