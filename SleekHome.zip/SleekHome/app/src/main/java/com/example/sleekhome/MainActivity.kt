package com.example.sleekhome

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.DragEvent
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowInsets
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {

    companion object {
        const val FIRST_CAP = 16   // page 1 has 4 columns x 4 rows (the clock takes 2 rows)
        const val FULL_CAP = 24    // other pages: 4 columns x 6 rows
    }

    private lateinit var root: FrameLayout
    private lateinit var column: LinearLayout
    private lateinit var pager: ViewPager2
    private lateinit var dotsRow: LinearLayout
    private lateinit var dock: LinearLayout

    private var apps: List<AppItem> = emptyList()
    private var dockApps: List<AppItem> = emptyList()
    private var entries: MutableList<Entry> = mutableListOf()

    private var overlay: FrameLayout? = null
    private var overlayContent: LinearLayout? = null
    private var refreshOnClose = false

    private var editMode = false
    private var doneBtn: TextView? = null
    private var dragEntry: Entry? = null
    private var dragView: View? = null
    private var edgePending = false
    private var edgeDir = 0

    private var topInset = 0
    private var navInset = 0
    private var imeInset = 0

    private val handler = Handler(Looper.getMainLooper())
    private val reloadRunnable = Runnable { reload() }
    private val edgeRunnable = Runnable {
        edgePending = false
        val count = pager.adapter?.itemCount ?: 0
        val next = pager.currentItem + edgeDir
        if (next in 0..(count - 2)) pager.setCurrentItem(next, true)
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            handler.removeCallbacks(reloadRunnable)
            handler.postDelayed(reloadRunnable, 600)
        }
    }

    private val gestures: GestureDetector by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent?, vx: Float, vy: Float): Boolean {
                if (e1 == null || e2 == null || overlay != null || editMode) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                val count = pager.adapter?.itemCount ?: 0
                val onLibrary = count > 0 && pager.currentItem == count - 1
                if (!onLibrary && dy > dp(80) && abs(dy) > abs(dx) * 1.5f &&
                    e1.y < root.height * 0.75f
                ) {
                    showOverlay(null, apps)
                    return true
                }
                return false
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        buildUi()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, filter)
        reload()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(reloadRunnable)
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: IllegalArgumentException) {
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Home button pressed: close overlays, leave edit mode, go to first page.
        closeOverlay()
        exitEdit()
        if (::pager.isInitialized) pager.setCurrentItem(0, true)
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        if (overlay != null) closeOverlay()
        else if (editMode) exitEdit()
        else if (::pager.isInitialized && pager.currentItem != 0) pager.setCurrentItem(0, true)
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (ev != null) gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        root = FrameLayout(this)
        column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        pager = ViewPager2(this).apply {
            offscreenPageLimit = 2
            (getChildAt(0) as? RecyclerView)?.overScrollMode = View.OVER_SCROLL_NEVER
            registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    updateDots(position)
                }
            })
        }
        dotsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(12), dp(10), dp(12))
            background = glassBackground(this@MainActivity, 34f, 0x40FFFFFF)
        }

        column.addView(pager, LinearLayout.LayoutParams(MATCH, 0, 1f))
        column.addView(dotsRow, LinearLayout.LayoutParams(MATCH, dp(24)))
        column.addView(
            dock,
            LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(14), dp(2), dp(14), dp(10)) }
        )
        root.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)

        root.setOnApplyWindowInsetsListener { _, ins ->
            val bars = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            topInset = bars.top
            navInset = bars.bottom
            imeInset = ins.getInsets(WindowInsets.Type.ime()).bottom
            applyInsets()
            ins
        }

        // Receives drag-and-drop events while rearranging icons.
        root.setOnDragListener { _, ev ->
            when (ev.action) {
                DragEvent.ACTION_DRAG_STARTED -> dragEntry != null
                DragEvent.ACTION_DRAG_LOCATION -> {
                    handleEdge(ev.x)
                    true
                }
                DragEvent.ACTION_DROP -> {
                    handleDrop(ev.x, ev.y)
                    true
                }
                DragEvent.ACTION_DRAG_ENDED -> {
                    handler.removeCallbacks(edgeRunnable)
                    edgePending = false
                    dragView?.alpha = 1f
                    dragView = null
                    dragEntry = null
                    true
                }
                else -> true
            }
        }
    }

    private fun applyInsets() {
        column.setPadding(0, topInset, 0, navInset)
        overlayContent?.setPadding(dp(16), topInset + dp(12), dp(16), max(navInset, imeInset) + dp(8))
    }

    private fun reload() {
        Thread {
            val list = AppRepository.load(this)
            runOnUiThread { if (!isDestroyed) rebuild(list) }
        }.start()
    }

    private fun rebuild(list: List<AppItem>) {
        apps = list
        dockApps = AppRepository.dockApps(this, list)
        val dockKeys = dockApps.map { it.component.flattenToString() }.toSet()
        entries = LayoutStore.load(this, list, dockKeys)

        dock.removeAllViews()
        dockApps.forEach { app ->
            dock.addView(
                IconCell(this, app.icon, app.label, false,
                    { v -> launch(app, v) },
                    { v -> showMenu(v, appMenu(app)) }),
                LinearLayout.LayoutParams(0, WRAP, 1f)
            )
        }
        renderPages()
    }

    private fun renderPages() {
        val chunks = mutableListOf<List<Entry>>()
        chunks.add(entries.take(FIRST_CAP))
        chunks.addAll(entries.drop(FIRST_CAP).chunked(FULL_CAP))

        val builders = mutableListOf<() -> View>()
        chunks.forEachIndexed { i, chunk -> builders.add { buildHomePage(chunk, i == 0) } }
        builders.add { buildLibrary() }

        val keep = if (pager.adapter == null) 0 else pager.currentItem
        pager.adapter = PageAdapter(builders)
        val target = min(keep, builders.size - 1)
        pager.setCurrentItem(target, false)
        buildDots(builders.size, target)
    }

    private fun buildHomePage(list: List<Entry>, first: Boolean): View {
        val header = if (first) clockWidget(this) else null
        val page = GridPage(this, 4, 6, 2, header)
        list.forEach { e ->
            val cell: View = when (e) {
                is Entry.App -> IconCell(this, e.item.icon, e.item.label, true,
                    { v -> if (!editMode) launch(e.item, v) },
                    { v ->
                        if (!editMode) {
                            showMenu(v, listOf(item("Edit Home Screen") { enterEdit() }) + appMenu(e.item))
                        }
                    })
                is Entry.Folder -> IconCell(this, AppRepository.renderFolderIcon(e.apps), e.name, true,
                    { _ -> showFolder(e) },
                    { v ->
                        if (!editMode) showMenu(v, listOf(item("Edit Home Screen") { enterEdit() }))
                    })
            }
            if (editMode) {
                attachDrag(cell, e)
                jiggle(cell)
            }
            page.addView(cell)
        }
        return page
    }

    private fun buildLibrary(): View = LibraryPage(
        this, apps,
        { a, v -> launch(a, v) },
        { a, v -> showMenu(v, appMenu(a)) },
        { showOverlay(null, apps) },
        { name, list -> showOverlay(name, list) }
    )

    private fun buildDots(n: Int, selected: Int) {
        dotsRow.removeAllViews()
        repeat(n) { i ->
            val d = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.WHITE)
                }
                alpha = if (i == selected) 1f else 0.35f
            }
            dotsRow.addView(d, LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
    }

    private fun updateDots(pos: Int) {
        for (i in 0 until dotsRow.childCount) {
            dotsRow.getChildAt(i).alpha = if (i == pos) 1f else 0.35f
        }
    }

    // ---------------------------------------------------------- Actions

    private fun item(title: String, action: () -> Unit): Pair<String, () -> Unit> = title to action

    private fun appMenu(app: AppItem): List<Pair<String, () -> Unit>> = listOf(
        item("App Info") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")))
        },
        item("Remove App") {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
        }
    )

    private fun launch(app: AppItem, from: View?) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val opts = from?.let {
            ActivityOptions.makeScaleUpAnimation(it, 0, 0, it.width, it.height).toBundle()
        }
        try {
            startActivity(i, opts)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showMenu(view: View, items: List<Pair<String, () -> Unit>>) {
        view.animate().scaleX(1.08f).scaleY(1.08f).setDuration(120).withEndAction {
            view.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
        val menu = PopupMenu(this, view)
        items.forEachIndexed { i, p -> menu.menu.add(0, i, i, p.first) }
        menu.setOnMenuItemClickListener { mi ->
            items[mi.itemId].second()
            true
        }
        menu.show()
    }

    // -------------------------------------------- Edit mode, drag, folders

    private fun enterEdit() {
        if (editMode) return
        editMode = true
        val b = TextView(this).apply {
            text = "Done"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = glassBackground(this@MainActivity, 18f, 0x66FFFFFF)
            setOnClickListener { exitEdit() }
        }
        doneBtn = b
        root.addView(
            b,
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply {
                topMargin = topInset + dp(8)
                rightMargin = dp(16)
            }
        )
        renderPages()
    }

    private fun exitEdit() {
        if (!editMode) return
        editMode = false
        doneBtn?.let { root.removeView(it) }
        doneBtn = null
        renderPages()
    }

    private fun jiggle(v: View) {
        val a = ObjectAnimator.ofFloat(v, View.ROTATION, -2f, 2f).apply {
            duration = 110L + (Math.random() * 40).toLong()
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }
        v.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(x: View) {
                if (!a.isStarted) a.start()
            }

            override fun onViewDetachedFromWindow(x: View) {
                a.cancel()
                x.rotation = 0f
            }
        })
    }

    private fun attachDrag(cell: View, entry: Entry) {
        var sx = 0f
        var sy = 0f
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        cell.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) > slop || abs(e.rawY - sy) > slop) {
                        dragEntry = entry
                        dragView = v
                        val started = v.startDragAndDrop(
                            ClipData.newPlainText("entry", "entry"),
                            View.DragShadowBuilder(v), null, 0
                        )
                        if (started) {
                            v.alpha = 0.3f
                        } else {
                            dragEntry = null
                            dragView = null
                        }
                        true
                    } else {
                        false
                    }
                }
                else -> false
            }
        }
    }

    /** Hold an icon near the left/right edge to flip pages while dragging. */
    private fun handleEdge(x: Float) {
        val dir = when {
            x < dp(36) -> -1
            x > root.width - dp(36) -> 1
            else -> 0
        }
        if (dir == 0) {
            handler.removeCallbacks(edgeRunnable)
            edgePending = false
        } else {
            edgeDir = dir
            if (!edgePending) {
                edgePending = true
                handler.postDelayed(edgeRunnable, 600)
            }
        }
    }

    private fun currentGridPage(): GridPage? {
        val rv = pager.getChildAt(0) as? RecyclerView ?: return null
        return rv.findViewHolderForAdapterPosition(pager.currentItem)?.itemView as? GridPage
    }

    private fun handleDrop(x: Float, y: Float) {
        val entry = dragEntry ?: return
        val count = pager.adapter?.itemCount ?: return
        val pageIdx = pager.currentItem
        if (pageIdx >= count - 1) return // can't drop on the App Library page
        val page = currentGridPage() ?: return

        val pageLoc = IntArray(2)
        val rootLoc = IntArray(2)
        page.getLocationOnScreen(pageLoc)
        root.getLocationOnScreen(rootLoc)
        val slot = page.slotAt(x + rootLoc[0] - pageLoc[0], y + rootLoc[1] - pageLoc[1]) ?: return

        val start = if (pageIdx == 0) 0 else FIRST_CAP + (pageIdx - 1) * FULL_CAP
        val pageCap = if (pageIdx == 0) FIRST_CAP else FULL_CAP
        val onPage = (entries.size - start).coerceIn(0, pageCap)
        val from = entries.indexOfFirst { it === entry }
        if (from < 0) return
        val target = start + min(slot.index, onPage)

        // Dropped on the middle of another app or folder: make or fill a folder.
        val onCenter = slot.fx in 0.25f..0.75f && slot.fy in 0.2f..0.8f
        if (entry is Entry.App && slot.index < onPage && target < entries.size &&
            target != from && onCenter
        ) {
            val t = entries[target]
            var merged = false
            if (t is Entry.App) {
                entries[target] = Entry.Folder("Folder", mutableListOf(t.item, entry.item))
                merged = true
            } else if (t is Entry.Folder) {
                t.apps.add(entry.item)
                merged = true
            }
            if (merged) {
                entries.removeAt(from)
                saveAndRender()
                return
            }
        }

        // Otherwise just move it to the new spot.
        if (target != from) {
            entries.removeAt(from)
            entries.add(min(target, entries.size), entry)
            saveAndRender()
        }
    }

    private fun saveAndRender() {
        LayoutStore.normalize(entries)
        LayoutStore.save(this, entries)
        renderPages()
    }

    private fun showFolder(folder: Entry.Folder) {
        if (overlay != null) return
        val o = FrameLayout(this).apply {
            setBackgroundColor(0x99000000.toInt())
            alpha = 0f
            setOnClickListener { closeOverlay() }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = glassBackground(this@MainActivity, 32f, 0x66808090)
            setPadding(dp(14), dp(16), dp(14), dp(18))
            isClickable = true
        }
        val title = EditText(this).apply {
            setText(folder.name)
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            setSingleLine(true)
            background = null
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    folder.name = s?.toString() ?: ""
                    LayoutStore.save(this@MainActivity, entries)
                }
            })
        }
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        folder.apps.chunked(3).forEach { rowApps ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowApps.forEach { app ->
                row.addView(
                    IconCell(this, app.icon, app.label, true,
                        { v ->
                            launch(app, v)
                            closeOverlay()
                        },
                        { v ->
                            showMenu(
                                v,
                                listOf(item("Remove from Folder") { removeFromFolder(folder, app) }) + appMenu(app)
                            )
                        }),
                    LinearLayout.LayoutParams(0, dp(96), 1f)
                )
            }
            repeat(3 - rowApps.size) {
                row.addView(View(this), LinearLayout.LayoutParams(0, dp(96), 1f))
            }
            grid.addView(row)
        }
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(grid)
        }
        card.addView(title, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        card.addView(scroll, LinearLayout.LayoutParams(MATCH, if (folder.apps.size > 12) dp(420) else WRAP))
        o.addView(
            card,
            FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER).apply { setMargins(dp(24), 0, dp(24), 0) }
        )
        root.addView(o, FrameLayout.LayoutParams(MATCH, MATCH))
        overlay = o
        overlayContent = null
        refreshOnClose = true
        o.animate().alpha(1f).setDuration(160).start()
    }

    private fun removeFromFolder(folder: Entry.Folder, app: AppItem) {
        folder.apps.remove(app)
        val idx = entries.indexOfFirst { it === folder }
        entries.add(if (idx >= 0) idx + 1 else entries.size, Entry.App(app))
        LayoutStore.normalize(entries)
        LayoutStore.save(this, entries)
        closeOverlay()
    }

    // ----------------------------------------------------------- Search

    /** title == null: global search. title != null: browse one library category. */
    private fun showOverlay(title: String?, base: List<AppItem>) {
        if (overlay != null) return
        val o = FrameLayout(this).apply {
            setBackgroundColor(0xE6101012.toInt())
            alpha = 0f
            setOnClickListener { closeOverlay() }
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val field = EditText(this).apply {
            hint = title ?: "Search"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(Color.WHITE)
            textSize = 17f
            setSingleLine(true)
            background = glassBackground(this@MainActivity, 14f)
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(results)
        }
        var first: AppItem? = null

        fun populate(q: String) {
            results.removeAllViews()
            val matches = when {
                title != null -> base.filter { q.isBlank() || it.label.contains(q, true) }
                q.isBlank() -> emptyList()
                else -> base.filter { it.label.contains(q, true) }
            }.take(60)
            first = matches.firstOrNull()
            matches.forEach { results.addView(resultRow(it)) }
        }

        field.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                populate(s?.toString() ?: "")
            }
        })
        field.setOnEditorActionListener { _, _, _ ->
            first?.let {
                launch(it, null)
                closeOverlay()
            }
            true
        }

        content.addView(field, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) })
        content.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        o.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(o, FrameLayout.LayoutParams(MATCH, MATCH))
        overlay = o
        overlayContent = content
        applyInsets()
        populate("")
        o.animate().alpha(1f).setDuration(160).start()

        if (title == null) {
            field.requestFocus()
            field.postDelayed({
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(field, InputMethodManager.SHOW_IMPLICIT)
            }, 100)
        }
    }

    private fun resultRow(app: AppItem): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(4), dp(8), dp(4), dp(8))
        addView(
            ImageView(context).apply { setImageBitmap(app.icon) },
            LinearLayout.LayoutParams(dp(46), dp(46))
        )
        addView(
            TextView(context).apply {
                text = app.label
                setTextColor(Color.WHITE)
                textSize = 17f
            },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(14) }
        )
        setOnClickListener {
            launch(app, it)
            closeOverlay()
        }
        setOnLongClickListener {
            showMenu(it, appMenu(app))
            true
        }
    }

    private fun closeOverlay() {
        val o = overlay ?: return
        overlay = null
        overlayContent = null
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(o.windowToken, 0)
        o.animate().alpha(0f).setDuration(140).withEndAction { root.removeView(o) }.start()
        if (refreshOnClose) {
            refreshOnClose = false
            renderPages()
        }
    }
}
