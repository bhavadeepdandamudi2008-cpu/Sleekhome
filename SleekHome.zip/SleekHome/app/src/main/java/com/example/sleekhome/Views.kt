package com.example.sleekhome

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** A grid slot plus where inside the cell (0..1) a point landed. */
data class Slot(val index: Int, val fx: Float, val fy: Float)

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun glassBackground(ctx: Context, radiusDp: Float, fill: Int = 0x33FFFFFF): GradientDrawable =
    GradientDrawable().apply {
        cornerRadius = ctx.dpf(radiusDp)
        setColor(fill)
    }

fun shadowedLabel(ctx: Context, label: String, sizeSp: Float): TextView = TextView(ctx).apply {
    text = label
    setTextColor(Color.WHITE)
    textSize = sizeSp
    maxLines = 1
    ellipsize = TextUtils.TruncateAt.END
    gravity = Gravity.CENTER
    setShadowLayer(6f, 0f, 1f, 0x99000000.toInt())
}

/** One app on the home screen: icon with an optional label underneath. */
class IconCell(
    ctx: Context,
    icon: Bitmap,
    label: String,
    showLabel: Boolean,
    clickCb: (View) -> Unit,
    longCb: (View) -> Unit
) : LinearLayout(ctx) {
    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        addView(
            ImageView(ctx).apply { setImageBitmap(icon) },
            LinearLayout.LayoutParams(ctx.dp(60), ctx.dp(60))
        )
        if (showLabel) {
            addView(
                shadowedLabel(ctx, label, 11f),
                LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(5) }
            )
        }
        setOnClickListener { clickCb(this) }
        setOnLongClickListener {
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            longCb(this)
            true
        }
    }
}

/** Fixed grid page (cols x rows). Optional header widget spans the first rows. */
class GridPage(
    ctx: Context,
    private val cols: Int,
    private val rows: Int,
    private val headerRows: Int,
    private val header: View?
) : ViewGroup(ctx) {

    init {
        header?.let { addView(it) }
    }

    private fun exact(px: Int) = MeasureSpec.makeMeasureSpec(px, MeasureSpec.EXACTLY)

    /** Which app slot is under (x, y) in this page's coordinates; null over the header. */
    fun slotAt(x: Float, y: Float): Slot? {
        if (width == 0 || height == 0) return null
        val cw = width.toFloat() / cols
        val ch = height.toFloat() / rows
        val col = (x / cw).toInt().coerceIn(0, cols - 1)
        val row = (y / ch).toInt().coerceIn(0, rows - 1)
        val skip = if (header != null) headerRows else 0
        if (row < skip) return null
        return Slot((row - skip) * cols + col, x / cw - col, y / ch - row)
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val h = MeasureSpec.getSize(heightSpec)
        setMeasuredDimension(w, h)
        val cw = w / cols
        val ch = h / rows
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            if (v === header) {
                v.measure(exact(w - context.dp(24)), exact(ch * headerRows - context.dp(16)))
            } else {
                v.measure(exact(cw), exact(ch))
            }
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = (r - l) / cols
        val ch = (b - t) / rows
        var idx = if (header != null) headerRows * cols else 0
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            if (v === header) {
                val x = context.dp(12)
                val y = context.dp(8)
                v.layout(x, y, x + v.measuredWidth, y + v.measuredHeight)
            } else {
                val col = idx % cols
                val row = idx / cols
                v.layout(col * cw, row * ch, col * cw + cw, row * ch + ch)
                idx++
            }
        }
    }
}

/** Date + time card shown at the top of the first page. */
fun clockWidget(ctx: Context): View {
    val box = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(ctx.dp(22), ctx.dp(12), ctx.dp(22), ctx.dp(12))
        background = glassBackground(ctx, 26f)
    }
    box.addView(TextClock(ctx).apply {
        format12Hour = "EEEE, d MMMM"
        format24Hour = "EEEE, d MMMM"
        setTextColor(0xCCFFFFFF.toInt())
        textSize = 14f
    })
    box.addView(TextClock(ctx).apply {
        format12Hour = "h:mm"
        format24Hour = "HH:mm"
        setTextColor(Color.WHITE)
        textSize = 48f
        typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    })
    return box
}

/** Last page: apps grouped into category cards, plus a search pill. */
class LibraryPage(
    ctx: Context,
    apps: List<AppItem>,
    private val launchCb: (AppItem, View) -> Unit,
    private val menuCb: (AppItem, View) -> Unit,
    private val searchCb: () -> Unit,
    private val categoryCb: (String, List<AppItem>) -> Unit
) : ScrollView(ctx) {

    init {
        isVerticalScrollBarEnabled = false
        overScrollMode = OVER_SCROLL_NEVER
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(16), ctx.dp(8), ctx.dp(16), ctx.dp(24))
        }
        col.addView(
            TextView(ctx).apply {
                text = "App Library"
                setTextColor(0xCCFFFFFF.toInt())
                textSize = 16f
                gravity = Gravity.CENTER_VERTICAL
                setPadding(ctx.dp(18), 0, ctx.dp(18), 0)
                background = glassBackground(ctx, 16f)
                setOnClickListener { searchCb() }
            },
            LinearLayout.LayoutParams(MATCH, ctx.dp(46)).apply { bottomMargin = ctx.dp(14) }
        )

        val groups = apps
            .groupBy { AppRepository.categoryName(it.category) }
            .toList()
            .sortedBy { AppRepository.CATEGORY_ORDER.indexOf(it.first) }

        groups.chunked(2).forEach { pair ->
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { (name, list) ->
                row.addView(
                    card(ctx, name, list),
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                        setMargins(ctx.dp(6), ctx.dp(6), ctx.dp(6), ctx.dp(6))
                    }
                )
            }
            if (pair.size == 1) {
                row.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
            }
            col.addView(row)
        }
        addView(col)
    }

    private fun card(ctx: Context, name: String, list: List<AppItem>): View {
        val wrap = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(8))
            background = glassBackground(ctx, 26f)
            setOnClickListener { categoryCb(name, list) }
        }
        list.take(4).chunked(2).forEach { pairApps ->
            val rowV = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            pairApps.forEach { app ->
                rowV.addView(
                    ImageView(ctx).apply {
                        setImageBitmap(app.icon)
                        setOnClickListener { launchCb(app, it) }
                        setOnLongClickListener { menuCb(app, it); true }
                    },
                    LinearLayout.LayoutParams(ctx.dp(58), ctx.dp(58)).apply {
                        setMargins(ctx.dp(5), ctx.dp(5), ctx.dp(5), ctx.dp(5))
                    }
                )
            }
            box.addView(rowV)
        }
        wrap.addView(box, LinearLayout.LayoutParams(WRAP, WRAP))
        wrap.addView(
            shadowedLabel(ctx, name, 12f),
            LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = ctx.dp(6) }
        )
        return wrap
    }
}

/** Each page gets its own view type so pages are never recycled into each other. */
class PageAdapter(private val builders: List<() -> View>) :
    RecyclerView.Adapter<PageAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v)

    override fun getItemViewType(position: Int): Int = position

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = builders[viewType]()
        v.layoutParams = RecyclerView.LayoutParams(MATCH, MATCH)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {}

    override fun getItemCount(): Int = builders.size
}
